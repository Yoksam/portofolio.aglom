// Burger Menu Toggle dengan fungsi buka/tutup yang smooth
const burger = document.querySelector('.burger');
const nav = document.querySelector('.nav-links');
const navLinks = document.querySelectorAll('.nav-links a');

// Fungsi toggle menu
function toggleMenu() {
    // Toggle class active pada nav
    nav.classList.toggle('active');
    
    // Toggle class active pada burger
    burger.classList.toggle('active');
    
    // Toggle body scroll
    document.body.style.overflow = nav.classList.contains('active') ? 'hidden' : '';
}

// Event listener untuk burger menu
burger.addEventListener('click', function(e) {
    e.stopPropagation();
    toggleMenu();
});

// Close menu ketika klik link
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        nav.classList.remove('active');
        burger.classList.remove('active');
        document.body.style.overflow = '';
    });
});

// Close menu ketika klik di luar
document.addEventListener('click', (e) => {
    if (nav.classList.contains('active') && 
        !nav.contains(e.target) && 
        !burger.contains(e.target)) {
        nav.classList.remove('active');
        burger.classList.remove('active');
        document.body.style.overflow = '';
    }
});

// Close menu dengan ESC key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && nav.classList.contains('active')) {
        nav.classList.remove('active');
        burger.classList.remove('active');
        document.body.style.overflow = '';
    }
});

// Smooth scrolling untuk anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add scroll effect to header
window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    if (window.scrollY > 100) {
        header.style.backgroundColor = 'rgba(44, 62, 80, 0.95)';
        header.style.backdropFilter = 'blur(10px)';
    } else {
        header.style.backgroundColor = '#2c3e50';
        header.style.backdropFilter = 'none';
    }
});

// Image Error Handler untuk Project Photos
function handleProjectImageError(img) {
    console.log('Foto project tidak ditemukan:', img.src);
    
    const altText = img.alt.toLowerCase();
    let fallbackUrl = '';
    
    // Tentukan fallback image berdasarkan jenis project
    if (altText.includes('windows') || altText.includes('instalasi')) {
        fallbackUrl = 'https://images.unsplash.com/photo-1566647387313-9fda80664848?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80';
    } else if (altText.includes('learning') || altText.includes('elearning')) {
        fallbackUrl = 'https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80';
    } else if (altText.includes('sistem') || altText.includes('informasi')) {
        fallbackUrl = 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80';
    } else if (altText.includes('portfolio') || altText.includes('website')) {
        fallbackUrl = 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80';
    } else if (altText.includes('mobile') || altText.includes('app')) {
        fallbackUrl = 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80';
    } else if (altText.includes('database')) {
        fallbackUrl = 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80';
    } else {
        fallbackUrl = 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80';
    }
    
    img.src = fallbackUrl;
    img.alt = 'Project Image - ' + altText;
}

// Initialize project images
document.addEventListener('DOMContentLoaded', function() {
    const projectImages = document.querySelectorAll('.project-img img');
    
    projectImages.forEach(img => {
        // Check if image loaded successfully
        if (!img.complete) {
            img.addEventListener('error', function() {
                handleProjectImageError(this);
            });
            
            img.addEventListener('load', function() {
                console.log('Foto project berhasil dimuat:', this.src);
            });
        }
    });
});

// Animation on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate');
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', () => {
    const elementsToAnimate = document.querySelectorAll('.skill-card, .project-card, .about-content, .contact-card');
    elementsToAnimate.forEach(el => {
        observer.observe(el);
    });
});

// Add loading animation
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
});

// Handle resize - close menu on desktop
window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        nav.classList.remove('active');
        burger.classList.remove('active');
        document.body.style.overflow = '';
    }
});

// foto bergerak
const foto = document.querySelector(".foto");

foto.addEventListener("click", () => {
  foto.classList.add("rotate");

  setTimeout(() => {
    foto.classList.remove("rotate");
  }, 600); //  durasi animasi
});

